<?php 
function wpvue_setup_theme()
{

    add_theme_support( 'title-tag' );

    add_theme_support( 'post-thumbnails' );

    add_theme_support( 'custom-logo', array(
        'height' => 160,
        'width' => 160,
    ) );

}
add_action( 'after_setup_theme', 'wpvue_setup_theme' );

add_action('init',function(){
	global $wp_filter;
	remove_action( 'template_redirect', 'redirect_canonical' );
	remove_action( 'template_redirect', 'maybe_redirect_404' );
	remove_action( 'template_redirect', 'wp_old_slug_redirect' );  
});

function wpvue_remove_redirects() {
	add_rewrite_rule( '^/(.+)/?', 'index.php', 'top' );
}
add_action( 'init', 'wpvue_remove_redirects' );

// Load scripts
function wpvue_load_dist() {
	wp_enqueue_script(
		'wp-vue-js',
		get_stylesheet_directory_uri() . '/dist/js/app.js',[],
		filemtime( get_stylesheet_directory() . '/dist/js/app.js' ),
		true
	);
	
	wp_enqueue_style(
		'wp-vue-css',
		get_stylesheet_directory_uri() . '/dist/css/app.css',
		null,
		filemtime( get_stylesheet_directory() . '/dist/css/app.css' )
	);
	wp_enqueue_style(
		'wp-vue-stylesheet',
		get_stylesheet_directory_uri() . '/style.css',
		null,
		filemtime( get_stylesheet_directory() . '/style.css' )
	);
}
add_action( 'wp_enqueue_scripts', 'wpvue_load_dist', 100 );
