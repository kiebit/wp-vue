<?php get_header(); ?>
  <noscript>
      <strong>We're sorry but example-vue doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
    </noscript>
    <div id="app"></div>
<?php get_footer();