<template>
  <div id="app" class="bg-white">
    <div id="header" class="border-b p-6 top-0 h-15">
      <div class="flex container relative mx-auto items-center justify-between flex-wrap px-6">
        <div class="w-1/2 nav-logo">
          <h1 class="title is-2 logo">
            <a href="/">
              <!-- <img alt="Vue logo" class="logo-img" src="./assets/logo.png" /> -->
              ABC Blog
            </a>
          </h1>
        </div>
        <div class="w-1/2" id="nav">
          <ul class="flex">
            <li class="mr-6">
              <router-link class="navbar-item" to="/">Home</router-link>
            </li>
            <li class="mr-6">
              <router-link class="navbar-item" to="/about">About</router-link>
            </li>
            <li class="mr-6">
              <router-link class="navbar-item" to="/contact">Contact</router-link>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container relative mx-auto px-6">
      <div class="content mt-6">
        <div class="flex">
          <div class="w-2/3">
            <router-view />
          </div>
          <div class="w-1/3">Right</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
@import "tailwindcss/base";
@import "tailwindcss/components";
@import "tailwindcss/utilities";
@import "./assets/style.scss";

#header {
}
.logo {
  color: $color-main;
}
.logo-img {
  max-width: 42px;
}
#nav {
  a {
    color: #2c3e50;
    &.router-link-exact-active {
      color: $color-main;
    }
  }
}
</style>
